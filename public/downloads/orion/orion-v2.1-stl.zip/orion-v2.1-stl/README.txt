Orion V2.1 printable parts (STL, millimetres)

One file per part. Print one of each, except:
- OR21-arm-r4-flush-plug.stl: print 16.
- OR21-10-lower-arm.stl and OR21-13-upper-arm-131mm-span.stl each hold both
  halves of that arm, laid out for printing.
- The six OR21-22 cap files are the left and right horn caps for the
  shoulder, elbow and wrist.

Status: the parts pass digital fit and slicer checks. Physical print fit,
strength and assembly have not been confirmed yet.
