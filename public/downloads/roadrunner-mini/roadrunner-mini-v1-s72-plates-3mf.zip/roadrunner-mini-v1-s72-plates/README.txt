Road Runner Mini v1 print plates (Bambu Studio 3MF, CAD state S72). MIT licence.

Open each file with File > Open Project, check the object count matches the plate name, and print
without changing the settings: orientation, walls, infill, supports and brim are saved in the file.
The single STL files and the test coupons are in the STL zip on the project page.
