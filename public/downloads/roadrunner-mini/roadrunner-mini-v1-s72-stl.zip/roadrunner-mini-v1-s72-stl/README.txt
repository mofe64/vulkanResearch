Road Runner Mini v1 printable parts (STL, millimetres, CAD state S72)
MIT licence. Source: https://github.com/mofe64/roadRunnerMiniV1
Assembly guide: https://vulkanresearch.com/projects/roadrunner-mini/assembly/

WHAT'S IN HERE
18 parts, one of each. The number after RR1- is the part number used in the
assembly guide and its 3D view. L and R are the robot's own left and right.

  01 chassis lower     02 chassis upper     03 tray             04 lid
  05 upper deck        06 IMU plate         07 pitch bracket    08 head
  09 wheel hubs        10 lower front plates
  11 lower rear links  12 upper front links 13 upper rear links

coupons/ holds two small test prints. Print them first (see below).

If you use a Bambu printer, the 3MF plate files (also on the project page)
already hold these parts in the right orientation with every setting saved.

PRINTER AND MATERIAL
Designed and tested on a Bambu Lab A1, 0.4 mm nozzle, Bambu PLA Basic,
0.20 mm layers. The full set uses about 540 g of PLA.

SETTINGS PER PART
Part                     Orientation                      Walls Infill  Supports              Brim
Head (08)                Upright                          4     30% gyr Tree, build plate only Auto
Pitch bracket (07)       On its long side                 5     40% gyr Tree, build plate only 5 mm outer
Upper links (12, 13)     Outer face down                  4     100%    None                  Auto
Hubs (09)                Flange face down                 4     100%    None                  Auto
Lower front plates (10)  Inner face down                  4     100%    None                  Auto
Lower rear links (11)    As laid out; one arm sits 39 mm  4     100%    Tree, everywhere      Auto
                         above the bed
Chassis lower (01)       Floor down                       4     30% gyr None                  5 mm outer
Chassis upper (02)       On its walls and posts           4     30% gyr Tree, build plate only 5 mm outer + inner
Upper deck (05)          Bottom face down                 4     30% gyr None                  Auto
Tray (03)                Floor down (open box)            4     30% gyr Tree, build plate only Auto
Lid (04)                 Top face down                    4     30% gyr Tree, build plate only Auto
IMU plate (06)           Flat side down, posts up         4     100%    None                  Auto

The leg parts are solid (100% infill) because they carry the whole robot
through small screw bosses.

WHY THE ORIENTATIONS MATTER
- Pitch bracket: print it on its long side so the layers run along its thin
  2 mm arms. Printed upright, the arms snap along a layer line.
- Lower rear links: the supports under the raised arm are needed.
- Chassis upper: after printing, clear the brim out of the corner-post holes.
- The chassis is two parts so each one has a large flat face on the bed.

TEST COUPONS: PRINT AND CHECK THESE FIRST
Print coupon_all.stl and coupon_horn_gauge.stl with the same printer,
filament and settings as the parts. Each check tells you whether a fit in the
real parts will work:

  M2 screw in the 1.8 mm hole     cuts its own thread; needs a screwdriver
  M2 screw in the 2.5 mm hole     passes through freely
  M3 screw in the 3.5 mm hole     passes through freely
  M3 heat-set insert, 4.0 mm hole goes in only with heat
  Servo horn in the 20.2 mm pocket stays in upside down, falls out when tapped
  8 mm tab in the slots           slides in without force
  STS3215 servo in the notch      goes in and moves freely side to side

If a check fails, tune the printer (flow, shrinkage or hole compensation)
before printing the real parts.

SUGGESTED PRINT ORDER
1. The coupons.
2. Head and pitch bracket: check that a servo, a horn and the OAK-D Lite fit.
3. The legs: hubs, upper links, lower front plates, lower rear links.
4. Chassis lower and upper, upper deck, IMU plate.
5. Tray and lid.

AFTER PRINTING
Fit the 20 M3 x 5 x 4 heat-set inserts before assembly (step 2 of the guide):
chassis upper 12, upper deck 4, hubs 4. Each must sit flush and straight.
Don't drill out the small M2 holes: they are undersized on purpose so the
screws can cut a thread.
